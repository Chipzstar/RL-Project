PLE with Gen. Deep RL
----------------------

**wip**

Show you how to train an RL agent using Vincent François' excellent framework: `General Deep RL`_.

.. _General Deep RL : https://github.com/VinF/General_Deep_Q_RL
